def main():
    __all__ = ["fzb"]
    print("Enjoy our module")

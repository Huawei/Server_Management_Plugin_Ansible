# Ansible module for HUAWEI iBMC (using Redfish APIs)

Ansible module and playbooks that use the Redfish API to manage huawei servers via the integrated huawei iBMC. 

## Why Ansible

Ansible is an open source automation engine that automates complex IT tasks such as cloud provisioning, application deployment and a wide variety of IT tasks. It is a one-to-many agentless mechanism where complicated deployment tasks can be controlled and monitored from a central control machine.

To learn more about Ansible, click [here](http://docs.ansible.com/).

## Why Redfish

Redfish is an open industry-standard specification and schema designed for modern and secure management of platform hardware. On PowerEdge servers the Redfish management APIs are available via the iBMC, which can be used by IT administrators to easily monitor and manage at scale their entire infrastructure using a wide array of clients on devices such as laptops, tablets and smart phones. 

To learn more about Redfish, click [here](https://www.dmtf.org/standards/redfish).

To learn more about the Redfish APIs available in the iBMC.

## Ansible and Redfish together

Together, Ansible and Redfish can be used by system administrators to fully automate at large scale server monitoring, alerting, configuration and firmware update tasks from one central location, significantly reducing complexity and helping improve the productivity and efficiency of IT administrators.

## How to install
1. tar -xvf Huawei-iBMC-Ansible_Module.tar
2. cd Huawei-iBMC-Ansible_Module 
3. python install.py


## How it works

A client talks to iBMC via its IP address by sending Redfish URIs that the iBMC will then process and send information back.



Your */etc/ansible/hosts* should look like this:

```
[myhosts]
# Hostname        iBMC IP               Host alias
host1.domain.com  ibmcip=192.168.0.101  host=webserver1 ibmcuser=root ibmcpswd='*****'
host2.domain.com  ibmcip=192.168.0.102  host=webserver2 ibmcuser=root ibmcpswd='*****'
host3.domain.com  ibmcip=192.168.0.103  host=dbserver1 ibmcuser=root ibmcpswd='*****'
...
```

## Example

Clone this repository. The ibmc module is in the *library* directory, it can be left there or placed somewhere else. If you move it, be sure to define the ANSIBLE_LIBRARY environment variable.

```bash
$ export ANSIBLE_LIBRARY=<directory-with-module>

$ ansible-playbook get_inventory.yml
  ...
PLAY [iBMC Get System Information] **********************************

TASK [Set timestamp ] **********************************************************
ok: [webserver1]
ok: [webserver2]
ok: [dbserver1]
  --- snip ---
```

You will see the usual task execution output, but please note that all server information retrieved is collected and put into text files defined by the *rootdir* variable in the playbook. The playbook creates a directory per server and places files there. For example:

```bash
$ cd <rootdir>/webserver1
$ ls
webserver1_inventory_20170728_142202.info
$ cat webserver1_inventory_20170728_142202.info
ServerHealth: OK
BiosVersion: 3.60
AssetTag:
ServiceTag: 12345
SerialNumber: 54321
MemoryGiB: 64
MemoryHealth: OK
CPUType: Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz
CPUHealth: OK
CPUCount: 2
PowerState: On
```

These files are in the format *{{host}}_{{datatype}}_{{datestamp}}* and each contains valuable server information. 

All server data is returned in JSON format and where appropriate it is extracted into an easy-to-read format. In this case, the file *webserver1_inventory_20170728_142202.txt* contains server data that has already been parsed for consumption.


```
$ jq '.result.Members[] | {Date: .Created, Message: .Message}' webserver1_SELogs_20170615_132201.json
{
  "Date": "2017-05-22T19:12:57-05:00",
  "Message": "The system halted because system power exceeds capacity."
}
{
  "Date": "2017-01-05T18:50:43-06:00",
  "Message": "The process of installing an operating system or hypervisor is successfully completed."
}
  --- snip ---

```

## Prerequisites

  - iBMC 
  - Minimum iBMC 2.56
  - python pip request
  - [jq](https://stedolan.github.io/jq/) JSON parser

## Support

